﻿using System;
using System.Linq;

namespace Lection2
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            int[,] matrix = new int[size, size];

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                var input = Console.ReadLine().Split().Select(int.Parse).ToArray();
                for (int j = 0; j < matrix.GetLength(0); j++)
                {
                    matrix[i, j] = input[j];
                }
            }
            int currentRowPriem = 0;
            int currentRowsecond = matrix.GetLength(0) -1;
            int currentColPrime = 0;
            int currentColsecond = 0;

            int sumPrimary = 0;
            int sumSecondary = 0;

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                sumPrimary += (matrix[currentRowPriem, currentColPrime]);
                currentRowPriem++;
                currentColPrime++;
            }
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                sumSecondary += (matrix[currentRowsecond, currentColsecond]);
                currentRowsecond--;
                currentColsecond++;
            }
            Console.WriteLine(Math.Abs(sumPrimary - sumSecondary));
        }
    }
}
