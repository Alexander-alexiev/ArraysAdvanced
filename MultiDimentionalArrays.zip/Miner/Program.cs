﻿using System;
using System.Linq;

namespace Miner
{
    class Program
    {
        static void Main(string[] args)
        {
            int sizeOfMatrix = int.Parse(Console.ReadLine());

            string[][] matrix = new string[sizeOfMatrix][];

            var commands = Console.ReadLine().Split(' ').ToArray();

            for (int row = 0; row < sizeOfMatrix; row++)
            {
                matrix[row] = Console.ReadLine().Split(' ').ToArray();
            }
            int minerRow = -1;
            int minerCol = -1;
            int numberOfCoals = 0;
            int endRow = -1;
            int endCol = -1;

            for (int row = 0; row < sizeOfMatrix; row++)
            {
                for (int col = 0; col < sizeOfMatrix; col++)
                {
                    if (matrix[row][col] == "c")
                    {
                        numberOfCoals++;
                    }
                    else if (matrix[row][col] == "s")
                    {
                        minerRow = row;
                        minerCol = col;
                    }
                    else if (matrix[row][col] == "e")
                    {
                        endRow = row;
                        endCol = col;
                    }
                }
            }

            for (int row = 0; row < commands.Length; row++)
            {
                bool isIn = CharIsIn(matrix, commands[row], minerRow, minerCol);
                
                if (isIn && commands[row] == "up")
                {
                    if (matrix[minerRow -1] [minerCol] == "c")
                    {
                        numberOfCoals--;
                        matrix[minerRow][minerCol] = "*";
                        matrix[minerRow -1][minerCol] = "s";
                        minerRow -= 1;
                        if (numberOfCoals == 0)
                        {
                            Console.WriteLine($"You collected all coals! ({minerRow}, {minerCol})");
                            return;
                        }
                    }
                    else if (matrix[minerRow -1][minerCol] == "e")
                    {
                        Console.WriteLine($"Game over! ({minerRow -1}, {minerCol})");
                        return;
                    }
                    else
                    {
                        matrix[minerRow][minerCol] = "*";
                        minerRow -= 1;
                    }
                }
                else if (isIn && commands[row] == "down")
                {
                    if (matrix[minerRow + 1][minerCol] == "c")
                    {
                        numberOfCoals--;
                        matrix[minerRow][minerCol] = "*";
                        matrix[minerRow + 1][minerCol] = "s";
                        minerRow += 1;
                        if (numberOfCoals == 0)
                        {
                            Console.WriteLine($"You collected all coals! ({minerRow}, {minerCol})");
                            return;
                        }
                    }
                    else if (matrix[minerRow + 1][minerCol] == "e")
                    {
                        Console.WriteLine($"Game over! ({minerRow + 1}, {minerCol})");
                        return;
                    }
                    else
                    {
                        matrix[minerRow][minerCol] = "*";
                        minerRow += 1;
                    }
                }
                else if (isIn && commands[row] == "left")
                {
                    if (matrix[minerRow][minerCol -1] == "c")
                    {
                        numberOfCoals--;
                        matrix[minerRow][minerCol] = "*";
                        matrix[minerRow][minerCol -1] = "s";
                        minerCol -= 1;
                        if (numberOfCoals == 0)
                        {
                            Console.WriteLine($"You collected all coals! ({minerRow}, {minerCol})");
                            return;
                        }
                    }
                    else if (matrix[minerRow][minerCol -1] == "e")
                    {
                        Console.WriteLine($"Game over! ({minerRow}, {minerCol -1})");
                        return;
                    }
                    else
                    {
                        matrix[minerRow][minerCol] = "*";
                        minerCol -= 1;
                    }
                }
                else if (isIn && commands[row] == "right")
                {
                    if (matrix[minerRow][minerCol + 1] == "c")
                    {
                        numberOfCoals--;
                        matrix[minerRow][minerCol] = "*";
                        matrix[minerRow][minerCol + 1] = "s";
                        minerCol += 1;
                        if (numberOfCoals == 0)
                        {
                            Console.WriteLine($"You collected all coals! ({minerRow}, {minerCol})");
                            return;
                        }
                    }
                    else if (matrix[minerRow][minerCol + 1] == "e")
                    {
                        Console.WriteLine($"Game over! ({minerRow}, {minerCol + 1})");
                        return;
                    }
                    else
                    {
                        matrix[minerRow][minerCol] = "*";
                        minerCol += 1;
                    }
                }


            }
            Console.WriteLine($"{ numberOfCoals} coals left. ({ minerRow}, { minerCol})");
        }

        public static bool CharIsIn(string[][] matrix, string v, int row, int col)
        {
            bool isIn = true;
            if (v == "up")
            {
                if (row - 1 < 0)
                {
                    isIn = false;
                }
                else
                {
                    isIn = true;
                }
            }
            else if (v == "down")
            {
                if (row + 1 >= matrix.Length)
                {
                    isIn = false;
                }
                else
                {
                    isIn = true;
                }
            }
            else if (v == "right")
            {
                if (col+ 1 >= matrix.Length)
                {
                    isIn = false;
                }
                else
                {
                    isIn = true;
                }
            }
            else if (v == "left")
            {
                if (col- 1 < 0)
                {
                    isIn = false;
                }
                else
                {
                    isIn = true;
                }
            }
            return isIn;
        }
    }
}
