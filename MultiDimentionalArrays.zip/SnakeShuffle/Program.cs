﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SnakeShuffle
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] dimentions = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries)
                 .Select(int.Parse).ToArray();
            int rows = dimentions[0];
            int cols = dimentions[1];

            char[][] matrix = new char[rows][];

            var snakeStr = Console.ReadLine().ToCharArray();

            Queue<char> snakeQueue = new Queue<char>(snakeStr);

            for (int row = 0; row < rows; row++)
            {
                matrix[row] = new char[cols];

                for (int col = 0; col < cols; col++)
                {
                    char charToAdd = snakeQueue.Dequeue();

                    matrix[row][col] = charToAdd;

                    snakeQueue.Enqueue(charToAdd);
                }
            }

            //Console.WriteLine(String.Join(Environment.NewLine, matrix.Select(r => String.Join( "",r))));

            //foreach (var row in matrix)
            //{
            //    Console.WriteLine(String.Join("", row));
            //}
            foreach (var row in matrix)
            {
                foreach (var col in row)
                {
                    Console.Write(col);
                    Console.WriteLine();
                }
            }
        }
    }
}
