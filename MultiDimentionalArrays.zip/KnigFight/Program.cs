﻿using System;

namespace KnigFight
{
    class Program
    {
        static void Main(string[] args)
        {
            int matrixBorders = int.Parse(Console.ReadLine());

            char[][] matrix = new char[matrixBorders][];

            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                matrix[row] = Console.ReadLine().ToCharArray();                
            }
            int removedKnigts = 0;

            while (true)
            {
                int maxAttacks = 0;
                int knightRow = -1;
                int knightCol = -1;

                for (int row = 0; row < matrixBorders; row++)
                {
                    for (int col = 0; col < matrixBorders; col++)
                    {
                        if (matrix[row][col] == 'K')
                        {
                            int tempAttack = CountAttacks(matrix, row, col);
                            if (tempAttack > maxAttacks)
                            {
                                maxAttacks = tempAttack;
                                knightRow = row;
                                knightCol = col;
                            }
                        }
                      
                    }
                }

                if (maxAttacks > 0)
                {
                    matrix[knightRow][knightCol] = '0';
                    removedKnigts++;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine(removedKnigts);

        }

        private static int CountAttacks(char[][] matrix, int row, int col)
        {
            int attacks = 0;
            if (IsInMatrix(row - 1, col - 2, matrix.Length) && matrix[row -1][col - 2] == 'K') 
            {
                attacks++;
            }
            if (IsInMatrix(row - 1, col + 2, matrix.Length) && matrix[row - 1][col + 2] == 'K')
            {
                attacks++;
            }
            if (IsInMatrix(row + 1, col - 2, matrix.Length) && matrix[row + 1][col - 2] == 'K')
            {
                attacks++;
            }
            if (IsInMatrix(row + 1, col + 2, matrix.Length) && matrix[row + 1][col + 2] == 'K')
            {
                attacks++;
            }
            if (IsInMatrix(row - 2, col - 1, matrix.Length) && matrix[row - 2][col - 1] == 'K')
            {
                attacks++;
            }
            if (IsInMatrix(row - 2, col + 1, matrix.Length) && matrix[row - 2][col + 1] == 'K')
            {
                attacks++;
            }
            if (IsInMatrix(row + 2, col - 1, matrix.Length) && matrix[row + 2][col - 1] == 'K')
            {
                attacks++;
            }
            if (IsInMatrix(row + 2, col + 1, matrix.Length) && matrix[row + 2][col + 1] == 'K')
            {
                attacks++;
            }
            return attacks;
        }

        private static bool IsInMatrix(int row, int col, int length)
        {
            return row >= 0 && row < length && col >= 0 && col < length;
        }
    }
}
