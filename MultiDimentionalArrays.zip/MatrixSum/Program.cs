﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Lection2
{
    class Program
    {
        static void Main(string[] args)
        {
            var size = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

            int[,] matrix = new int[size[0], size[1]];
            int biggestSum = 0;
            int startIndexrow = 0;
            int startindexcol = 0;
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                var input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    matrix[row, col] = input[col];
                }
            }
            for (int row = 0; row < matrix.GetLength(0) - 2; row++)
            {
                
                for (int col = 0; col < matrix.GetLength(1) - 2; col++)
                {
                    int sume = 0;
                    sume += matrix[row, col]
                        + matrix[row, col + 1]
                        + matrix[row, col + 2]
                        + matrix[row + 1, col]
                        + matrix[row + 1, col+1]
                        + matrix[row + 1, col + 2]
                        + matrix[row + 2, col]
                        + matrix[row + 2, col + 1]
                        + matrix[row + 2, col + 2];

                    if (sume > biggestSum)
                    {
                        startindexcol = col;
                        startIndexrow = row;
                        biggestSum = sume;
                    }
                }
            }
            Console.WriteLine("Sum = "+biggestSum);
            for (int i = 0; i < 3; i++)
            {
                Console.Write(matrix[startIndexrow,startindexcol +i] + " ");
            }
            Console.WriteLine();
            for (int i = 0; i < 3; i++)
            {
                Console.Write(matrix[startIndexrow +1, startindexcol + i]+ " ");
            }
            Console.WriteLine();
            for (int i = 0; i < 3; i++)
            {
                Console.Write(matrix[startIndexrow +2, startindexcol + i] + " ");
            }
        }
    }
}
